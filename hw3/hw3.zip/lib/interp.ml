open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds


let rec eval_expr : expr -> exp_val ea_result = fun e ->
  match e with
  | Int(n) ->
    return @@ NumVal n
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1+n2)
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1-n2)
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1*n2)
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return @@ NumVal (n1/n2)
  | Let(id,def,body) ->
    eval_expr def >>=
    extend_env id >>+
    eval_expr body
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return @@ BoolVal (n = 0)
  | Proc(id,_,e)  ->
    lookup_env >>= fun en ->
    return (ProcVal(id,e,en))
  | App(e1,e2)  -> 
    eval_expr e1 >>= 
    clos_of_procVal >>= fun (id,e,en) ->
    eval_expr e2 >>= fun ev ->
    return en >>+
    extend_env id ev >>+
    eval_expr e
  | Abs(e1)      ->
    eval_expr e1  >>=
    int_of_numVal >>= fun n ->
    return @@ NumVal (abs n)
  | Record(fs) ->
    (* if (record_help fs) = false
    then error "Record: duplicate fields"
    else *) 
    map (fun (_, e) -> eval_expr e) fs >>= fun vs ->
    return @@ RecordVal (List.map2 (fun (id,_) v -> (id, v)) fs vs)
  | Proj(e,id) ->
    eval_expr e >>=
    list_of_recordVal >>= fun fs ->
    (match List.assoc_opt id fs with
    | None -> error "Proj: field does not exist"
    | Some ev -> return ev)  
  | Cons(e1, e2) ->
    eval_expr e1 >>= fun n1 ->
    eval_expr e2 >>= list_of_listVal >>= fun n2 ->
    return (ListVal(n1::n2))
  | Hd(e1) ->
    eval_expr e1 >>= list_of_listVal >>= fun n1 ->
    (match n1 with
    | h::t -> return (h)
    | [] -> error ("List is empty"))
  | Tl(e1) ->
    eval_expr e1 >>= list_of_listVal >>= tail
  | IsEmpty(e1)  ->
    eval_expr e1 >>= tree_of_treeVal >>= fun n1 ->
    match n1 with 
    | _-> return @@ BoolVal(false)
    | Empty -> return @@ BoolVal(true)
  | EmptyList  ->
    return (ListVal ([]))
  | EmptyTree ->
    return (TreeVal(Empty))
  | Node(e1,lte,rte) ->
    eval_expr e1 >>= fun n ->
    eval_expr lte >>=
    tree_of_treeVal >>= fun lt ->
    eval_expr rte >>=
    tree_of_treeVal >>= fun rt ->
    return @@ (TreeVal (Node(n, lt, rt)))
  | CaseT(target,emptycase,id1,id2,id3,nodecase) ->
    eval_expr targe >>= 
    tree_of_treeVal >>= fun targ -> 
    match targ with
    |Empty -> eval_expr emptycase >>= fun e -> 
      return e
    |Node(d, l, r) -> 
      extend_env id1 d >>+
      extend_env id2 (TreeVal (l)) >>+
      extend_env id3 (TreeVal (r)) >>+
      eval_expr nodecase >>= fun n ->
      return n
  | Tuple(es) ->
    sequence(List.map eval_expr es) >>= fun e1 -> 
    return (TupleVal(e1))
  | Untuple(ids,e1,e2) ->
    eval_expr e1 >>= tuple_of_tupleVal >>= fun n1 ->
    if((List.length n1) != (List.length ids)) then error "extend_env_list: Arguments do not match parameters!"
    else (let rec aux n2 n1 = 
    match n2, n1 with
    | [h1] , [h2]  -> (extend_env h1 h2) >>+ (eval_expr e2)
    | h1::t1, h2::t2 -> (extend_env h1 h2) >>+ (aux t1 t2) in 
    (aux ids n1))
  | Debug(_e) ->
    string_of_env >>= fun str ->
    print_endline str; 
    error "Debug called"
  | _ -> failwith "Not implemented yet!"

(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c

